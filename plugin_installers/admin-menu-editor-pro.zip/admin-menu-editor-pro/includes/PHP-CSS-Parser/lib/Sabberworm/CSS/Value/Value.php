<?php

namespace Sabberworm\CSS\Value;

abstract class Value {

	public abstract function __toString();
}
