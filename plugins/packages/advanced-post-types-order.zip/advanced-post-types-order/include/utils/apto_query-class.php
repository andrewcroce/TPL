<?php


    class APTO_query_utils
        {
            static function filter_valid_data($query)
                {
                    //filter the taxonomies
                    if(is_array($query) && count($query) > 0)
                        {
                            $query  =   self::data_sanitize($query);
                        }
                           
                    return $query;   
                    
                }
                
            static function data_sanitize($queries)
                {
                    $cleaned_query = array();
                    
                    $same_level_taxonomies  =   array();
                                
                    foreach($queries as $key  =>  $data)
                        {
                            if ( 'relation' === $key ) 
                                {
                                    $cleaned_query['relation'] = $data;

                                // First-order clause.
                                } 
                            else if ( self::is_first_order_clause( $data ) ) 
                                {
                                    if((isset($data['terms']) && is_array($data['terms']) && count(array_filter($data['terms'])) > 0) 
                                            || (isset($data['terms']) && !is_array($data['terms']) && $data['terms'] != ''))
                                            {
                                                $data['terms']   =   array_filter($data['terms']);
                                                
                                                //check for duplicate
                                                if(self::level_query_same_query_exists($data, $same_level_taxonomies))
                                                    continue;
                                                
                                                $cleaned_query[] = $data;
                                                
                                                $same_level_taxonomies[]    =   $data;  
                                            }

                                // Otherwise, it's a nested query, so we recurse.
                                } 
                            else if ( is_array( $data ) ) 
                                {
                                    $cleaned_subquery = self::data_sanitize( $data );

                                    if ( ! empty( $cleaned_subquery ) ) 
                                        {
                                            $cleaned_query[] = $cleaned_subquery;
                                        }
                                }
                                             
                        }
                    
                                        
                    return $cleaned_query;
                }
            
            static function is_first_order_clause($query)
                {
                    return is_array( $query ) && ( empty( $query ) || array_key_exists( 'terms', $query ) || array_key_exists( 'taxonomy', $query ) || array_key_exists( 'include_children', $query ) || array_key_exists( 'field', $query ) || array_key_exists( 'operator', $query ) );    
                }
            
            static function level_query_same_query_exists($data, $same_level_taxonomies)
                {
                    if(count($same_level_taxonomies) < 1)
                        return FALSE;
                    
                    foreach($same_level_taxonomies  as  $same_level_taxonomy)
                        {
                            if(isset($data['taxonomy']) && isset($same_level_taxonomy['taxonomy'])  && isset($data['terms'])  && isset($same_level_taxonomy['terms'])   && isset($data['field'])  && isset($same_level_taxonomy['field']))
                                {
                                    if($data['taxonomy']    !=  $same_level_taxonomy['taxonomy'])
                                        continue;
                                        
                                    //check against the operator if booth exists
                                    if(isset($data['operator']) && isset($same_level_taxonomy['operator'])  &&  $data['operator'] !=  $same_level_taxonomy['operator'])
                                        continue;
                                    
                                    $field_id               =   strtolower($data['field']);
                                    if($field_id    ==  'id')
                                        $field_id   =   'term_id';
                                    $field_id_same_level    =   strtolower($same_level_taxonomy['field']);
                                    if($field_id_same_level    ==  'id')
                                        $field_id_same_level   =   'term_id';
                                    if($field_id    !=  $field_id_same_level)
                                        continue;
                                        
                                    $terms                  =   (array)$data['terms'];
                                    $terms_same_level       =   (array)$same_level_taxonomy['terms'];
                                    if(count($terms) != count($terms_same_level))
                                        continue;
                                    
                                    if(count(array_diff($terms, $terms_same_level)) > 0)
                                        continue;
                                        
                                    return TRUE;
                                }
                        }
                        
                    return FALSE;                    
                }
                
            static function queries_count($queries)
                {
                    $filtred_queries    =   self::get_tax_queries($queries);
                                  
                    return count($filtred_queries);
                }
                
            static function get_tax_queries($queries)
                {
                    $filtred_queries    =   array();
                    
                    foreach($queries as $key  =>  $data)
                        {
                            if ( 'relation' === $key ) 
                                {
               
                                } 
                            else if ( self::is_first_order_clause( $data ) ) 
                                {
                                    //this is a tax query
                                    $filtred_queries[]  =   $data;

                                } 
                            else if ( is_array( $data ) ) 
                                {
                                    //this is a nested subquery
                                    //TO BE IMPLEMENTED
                                }
                        }
                        
                    return $filtred_queries;
                }
            
        }

?>